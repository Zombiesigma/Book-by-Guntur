function openNovel(url) {
    window.location.href = url;
}

function goBack() {
    window.history.back();
}